-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Generation Time: May 19, 2024 at 03:35 PM
-- Server version: 5.7.44
-- PHP Version: 8.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prijava_za_putno_osiguranje`
--

-- --------------------------------------------------------

--
-- Table structure for table `additional_insured`
--

CREATE TABLE `additional_insured` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `passport_number` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `additional_insured`
--

INSERT INTO `additional_insured` (`id`, `full_name`, `date_of_birth`, `passport_number`) VALUES
(6, 'tesst', '2001-01-23', '123123');

-- --------------------------------------------------------

--
-- Table structure for table `insurance_carrier`
--

CREATE TABLE `insurance_carrier` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `passport_number` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `insurance_carrier`
--

INSERT INTO `insurance_carrier` (`id`, `full_name`, `date_of_birth`, `passport_number`, `phone`, `email`) VALUES
(17, 'Aleksandar Jockovic', '2000-11-18', '123123123', '+381691704689', 'aleksandarjockovic227@gmail.com'),
(18, 'Test Test', '1998-02-23', '321321321', '', 'test@test.com');

-- --------------------------------------------------------

--
-- Table structure for table `insurance_policy`
--

CREATE TABLE `insurance_policy` (
  `id` int(11) NOT NULL,
  `insurance_carrier_id` int(11) NOT NULL,
  `insertion_date` date NOT NULL,
  `date_of_travel_from` date NOT NULL,
  `date_of_travel_to` date NOT NULL,
  `number_of_days` int(11) NOT NULL,
  `type_of_insurance_policy` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `insurance_policy`
--

INSERT INTO `insurance_policy` (`id`, `insurance_carrier_id`, `insertion_date`, `date_of_travel_from`, `date_of_travel_to`, `number_of_days`, `type_of_insurance_policy`) VALUES
(14, 17, '2024-05-19', '2024-11-03', '2024-11-23', 21, 'individualno'),
(15, 18, '2024-05-19', '2024-11-28', '2024-11-28', 1, 'grupno');

-- --------------------------------------------------------

--
-- Table structure for table `insurance_policy_additional_insured`
--

CREATE TABLE `insurance_policy_additional_insured` (
  `id` int(11) NOT NULL,
  `insurance_policy_id` int(11) NOT NULL,
  `additional_insured_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `insurance_policy_additional_insured`
--

INSERT INTO `insurance_policy_additional_insured` (`id`, `insurance_policy_id`, `additional_insured_id`) VALUES
(6, 15, 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `additional_insured`
--
ALTER TABLE `additional_insured`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `insurance_carrier`
--
ALTER TABLE `insurance_carrier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `insurance_policy`
--
ALTER TABLE `insurance_policy`
  ADD PRIMARY KEY (`id`),
  ADD KEY `insurance_carrier_id` (`insurance_carrier_id`);

--
-- Indexes for table `insurance_policy_additional_insured`
--
ALTER TABLE `insurance_policy_additional_insured`
  ADD PRIMARY KEY (`id`),
  ADD KEY `insurance_policy_id` (`insurance_policy_id`),
  ADD KEY `additional_insured_id` (`additional_insured_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `additional_insured`
--
ALTER TABLE `additional_insured`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `insurance_carrier`
--
ALTER TABLE `insurance_carrier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `insurance_policy`
--
ALTER TABLE `insurance_policy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `insurance_policy_additional_insured`
--
ALTER TABLE `insurance_policy_additional_insured`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `insurance_policy`
--
ALTER TABLE `insurance_policy`
  ADD CONSTRAINT `insurance_policy_ibfk_1` FOREIGN KEY (`insurance_carrier_id`) REFERENCES `insurance_carrier` (`id`);

--
-- Constraints for table `insurance_policy_additional_insured`
--
ALTER TABLE `insurance_policy_additional_insured`
  ADD CONSTRAINT `insurance_policy_additional_insured_ibfk_1` FOREIGN KEY (`insurance_policy_id`) REFERENCES `insurance_policy` (`id`),
  ADD CONSTRAINT `insurance_policy_additional_insured_ibfk_2` FOREIGN KEY (`additional_insured_id`) REFERENCES `additional_insured` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
